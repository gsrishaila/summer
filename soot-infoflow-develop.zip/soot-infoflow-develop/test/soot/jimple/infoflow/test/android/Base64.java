package soot.jimple.infoflow.test.android;

public class Base64 {
	
	public static String encodeToString(@SuppressWarnings("unused") byte[] input) {
		return "";
	}

}
