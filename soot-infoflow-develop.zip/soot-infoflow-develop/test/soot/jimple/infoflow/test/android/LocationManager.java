package soot.jimple.infoflow.test.android;

public class LocationManager {
	
	public static double getLongitude() {
		return 3.1415d;
	}
	
	public static Location getLastKnownLocation() {
		return new Location();
	}

}
