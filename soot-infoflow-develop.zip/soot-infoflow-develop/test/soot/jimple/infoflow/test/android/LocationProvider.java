package soot.jimple.infoflow.test.android;

public class LocationProvider {

}
