/*******************************************************************************
 * Copyright (c) 2012 Secure Software Engineering Group at EC SPRIDE.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v2.1
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * 
 * Contributors: Christian Fritz, Steven Arzt, Siegfried Rasthofer, Eric
 * Bodden, and others.
 ******************************************************************************/
package soot.jimple.infoflow.test.securibench;


public class ReflectionTests extends JUnitTests {
//	@Test
//	public void refl1() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.reflection.Refl1: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void refl2() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.reflection.Refl2: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void refl3() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.reflection.Refl3: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void refl4() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.reflection.Refl4: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}


}
