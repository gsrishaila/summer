/*******************************************************************************
 * Copyright (c) 2012 Secure Software Engineering Group at EC SPRIDE.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v2.1
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * 
 * Contributors: Christian Fritz, Steven Arzt, Siegfried Rasthofer, Eric
 * Bodden, and others.
 ******************************************************************************/
package soot.jimple.infoflow.test.securibench;


public class SanitizerTests {
	
//	@Test
//	public void sanitizers1() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers1: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void sanitizers2() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers2: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void sanitizers3() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers3: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void sanitizers4() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers4: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void sanitizers5() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers5: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void sanitizers6() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.sanitizers.Sanitizers6: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}


}
