package scm;

                                // a generic object for the
                                // evaluator.
interface Obj
{ Obj eval(Env e) throws Exception; }
